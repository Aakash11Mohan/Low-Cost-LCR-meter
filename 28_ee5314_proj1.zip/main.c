#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "tm4c123gh6pm.h"
#include "driverlib/pin_map.h"

#define RED_LED      (*((volatile uint32_t *)(0x42000000 + (0x400253FC-0x40000000)*32 + 1*4)))
#define HIGHSIDE_R   (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 2*4))) //PD2
#define MEASURE_LR   (*((volatile uint32_t *)(0x42000000 + (0x400073FC-0x40000000)*32 + 3*4))) //PD3
#define MEASURE_C    (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 1*4))) //PE1
#define LOWSIDE_R    (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 2*4))) //PE2
#define INTEGRATE    (*((volatile uint32_t *)(0x42000000 + (0x400243FC-0x40000000)*32 + 3*4))) //PE1

uint32_t i, count = 0, count1 = 0, count2 = 0, argc = 0;
uint32_t pos[81];
uint32_t a,validcmd;
uint32_t max_char = 80;
uint32_t min_argc=0;
char s; //switch case
char str[81];
char str1[81];
char type[81];
char c,ch;
char* arg1;char* arg2;

// hardware initialization function
void initHw()
{
    // Configure HW to work with 16 MHz XTAL, PLL enabled, system clock of 40 MHz
    SYSCTL_RCC_R = SYSCTL_RCC_XTAL_16MHZ | SYSCTL_RCC_OSCSRC_MAIN
            | SYSCTL_RCC_USESYSDIV | (4 << SYSCTL_RCC_SYSDIV_S);

    // Set GPIO ports to use AP (not needed since default configuration -- for clarity)
    SYSCTL_GPIOHBCTL_R = 0;

    // Enable GPIO port F peripherals
    SYSCTL_RCGC2_R = SYSCTL_RCGC2_GPIOF | SYSCTL_RCGC2_GPIOA | SYSCTL_RCGC2_GPIOD | SYSCTL_RCGC2_GPIOE ;

    // Configure LED
    GPIO_PORTF_DIR_R = 0x02;  // bit 1 is output
    GPIO_PORTF_DR2R_R = 0x02; // set drive strength to 2mA (not needed since default configuration -- for clarity)
    GPIO_PORTF_DEN_R = 0x02;  // enable LED

    // Configure Measure pins
    GPIO_PORTD_DIR_R = 0x0c;  // bit 2 & 3 is output
    GPIO_PORTD_DR2R_R = 0x0c; // set drive strength to 2mA (not needed since default configuration -- for clarity)
    GPIO_PORTD_DEN_R = 0x0c;  // enable PD2,PD3
    GPIO_PORTE_DIR_R = 0x0e;  // bit 1,2 & 3 is output
    GPIO_PORTE_DR2R_R = 0x0e; // set drive strength to 2mA (not needed since default configuration -- for clarity)
    GPIO_PORTE_DEN_R = 0x0e;  // enable PE1,PE2,PE3

    // Configure UART0 pins
    SYSCTL_RCGCUART_R |= SYSCTL_RCGCUART_R0; // turn-on UART0, leave other uarts in same status
    GPIO_PORTA_DEN_R |= 3;                         // default, added for clarity
    GPIO_PORTA_AFSEL_R |= 3;                       // default, added for clarity
    GPIO_PORTA_PCTL_R = GPIO_PCTL_PA1_U0TX | GPIO_PCTL_PA0_U0RX;

    // Configure UART0 to 115200 baud, 8N1 format (must be 3 clocks from clock enable and config writes)
    UART0_CTL_R = 0;                 // turn-off UART0 to allow safe programming
    UART0_CC_R = UART_CC_CS_SYSCLK;                 // use system clock (40 MHz)
    UART0_IBRD_R = 21; // r = 40 MHz / (Nx115.2kHz), set floor(r)=21, where N=16
    UART0_FBRD_R = 45;                               // round(fract(r)*64)=45
    UART0_LCRH_R = UART_LCRH_WLEN_8 | UART_LCRH_FEN; // configure for 8N1 w/ 16-level FIFO
    UART0_CTL_R = UART_CTL_TXE | UART_CTL_RXE | UART_CTL_UARTEN; // enable TX, RX, and module
}

// Blocking function that writes a serial character when the UART buffer is not full
void putcUart0(char c)
{
    while (UART0_FR_R & UART_FR_TXFF)
        ;
    UART0_DR_R = c;
}

// Blocking function that writes a string when the UART buffer is not full
void putsUart0(char* str)
{
    uint8_t i;
    for (i = 0; i < strlen(str); i++)
        putcUart0(str[i]);
}

// Blocking function that returns with serial data once the buffer is not empty
char getcUart0()
{
    while (UART0_FR_R & UART_FR_RXFE)
        ;
    return UART0_DR_R & 0xFF;
}

// on and off for 500ms
void waitmillisec(uint32_t ms)
{
    __asm("WMS_LOOP0:   MOV  R1, #6");
    // 1
    __asm("WMS_LOOP1:   SUB  R1, #1");
    // 6
    __asm("             CBZ  R1, WMS_DONE1");
    // 5+1*3
    __asm("             NOP");
    // 5
    __asm("             NOP");
    // 5
    __asm("             B    WMS_LOOP1");
    // 5*2 (speculative, so P=1)
    __asm("WMS_DONE1:   SUB  R0, #1");
    // 1
    __asm("             CBZ  R0, WMS_DONE0");
    // 1
    __asm("             NOP");
    // 1
    __asm("             B    WMS_LOOP0");
    // 1*2 (speculative, so P=1)
    __asm("WMS_DONE0:");
    // ---
    // 40 clocks/us + error

}

// flashing red led
void led()
{
    RED_LED = 1;
    waitmillisec(500000);
    RED_LED = 0;
}

// getting string from user step 2
int getstring()
{
    while (1)
    {
        count = 0;
        Jump: c = getcUart0();
              ch=tolower(c);
        if (c == 8)
        {
            if (count > 0)
            {
                count--;
                goto Jump;
            }
            else
            {
                goto Jump;
            }
        }
        if (c == 13)
        {
            str[count] = 0;
            break;
        }
        else
        {
            if ((c >= 32) || (c == 9))
            {
                str[count++] = ch;
                if (count == max_char)
                {
                    str[count + 1] = '\0';
                    break;
                }
                else
                {
                    goto Jump;
                }
            }
            else
            {
                goto Jump;
            }
        }
    }
    return str;
}


// parsing of string step 3
int parsestring()
{
    for(i=0;i<strlen(str);i++)
    {
        if((str[i] >= 97 && str[i] <= 122)||(str[i]==95))
        {
            if((str[i-1] >= 97 && str[i-1] <= 122)||(str[i-1]==95))
            {
                goto Jump1;
            }
            else
            {
                argc++;
                pos[count1]=i;
                type[count2]='a';
                count1++;
                count2++;
                str1[i]=str[i];
            }
            Jump1:str1[i]=str[i];
        }
        else if((str[i] >= 48) && (str[i] <= 57))
        {
            if((str[i-1]>=48) && (str[i-1]<=57))
            {
                goto Jump1;
            }
            else
            {
                argc++;
                pos[count1]=i;
                type[count2]='n';
                count1++;
                count2++;
                str1[i]=str[i];
            }

        }
        else if((str[i]==32) || (str[i]==43) || (str[i]==44) || (str[i]==45) || (str[i]==46) || (str[i]==47))
        {
            str1[i]='\0';
        }

    }
    /*for(i=0;i<argc;i++)
    {
        putsUart0(str1+pos[i]);
        putsUart0("\n\r");
    }*/
    if((strcmp("set",&str1[pos[0]])==0))
    {
        min_argc=argc-1;
        return min_argc;
    }
}


char* getvalue(int y)    // THIS LOOP GETS CHARACTERS ENTERED BY THE USER FROM FIELD POSITION FROM PARSER
{
    char *j = &str1[pos[y]];

    return j;

}

bool iscommand(char* verb,int set_arg)
{
    if((strcmp(verb,&str1[pos[0]])==0) && (strcmp(set_arg,min_argc)==0))
        return 1;
    else
        return 0;

}


// supporting commands step 4
commands()
{
    if(iscommand("set",2))
    {
        arg1 = getvalue(1);
        arg2 = getvalue(2);

                if ((strcmp(arg1, "meas_c")) == 0 && (strcmp(arg2, "on")) == 0)
                {
                    MEASURE_LR = 0;
                    MEASURE_C = 1;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "meas_c")) == 0 && (strcmp(arg2, "off")) == 0)
                {
                    MEASURE_C = 0;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "meas_lr")) == 0 && (strcmp(arg2, "on")) == 0)
                {
                     MEASURE_C = 0;
                     MEASURE_LR = 1;
                     //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "meas_lr")) == 0 && (strcmp(arg2, "off")) == 0)
                {
                     MEASURE_LR = 0;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "highside_r")) == 0 && (strcmp(arg2, "on")) == 0)
                {
                    LOWSIDE_R=0;
                    HIGHSIDE_R = 1;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "highside_r")) == 0 && (strcmp(arg2, "off")) == 0)
                {

                    HIGHSIDE_R = 0;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "lowside_r")) == 0 && (strcmp(arg2, "on")) == 0)
                {
                    HIGHSIDE_R=0;
                    LOWSIDE_R = 1;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "lowside_r")) == 0 && (strcmp(arg2, "off")) == 0)
                {
                    LOWSIDE_R = 0;
                    //putsUart0("\n\r TRUE");
                }
                else if ((strcmp(arg1, "integrate")) == 0 && (strcmp(arg2, "on")) == 0)
                {

                    //putsUart0("\n\r TRUE");
                    Jump3:putsUart0("\n\r ");
                    putsUart0("Select");
                    putsUart0("1)Lowside on 2)Highside on 3)None:");
                    putsUart0("\n\r");
                    s=getcUart0();
                    switch(s)
                    {
                        case '1':

                                if(iscommand("set",2))
                                    {
                                        arg1 = getvalue(1);
                                        arg2 = getvalue(2);
                                        if ((strcmp(arg1, "lowside_r")) == 0 && (strcmp(arg2, "on")) == 0)
                                        {
                                           HIGHSIDE_R=0;
                                           LOWSIDE_R = 1;
                                        }
                                    }
                                putsUart0("\n\r");
                                break;
                        case '2':

                                if(iscommand("set",2))
                                    {
                                       arg1 = getvalue(1);
                                       arg2 = getvalue(2);
                                       if ((strcmp(arg1, "highside_r")) == 0 && (strcmp(arg2, "on")) == 0)
                                       {
                                          LOWSIDE_R = 0;
                                          HIGHSIDE_R=1;
                                       }
                                    }
                                putsUart0("\n\r");
                                break;
                        case '3':
                                INTEGRATE = 1;
                                putsUart0("\n\r");
                                break;
                        default:
                               putsUart0("\n\r");
                               putsUart0("wrong selection");
                               goto Jump3;

                    }

                }
                else if ((strcmp(arg1, "integrate")) == 0 && (strcmp(arg2, "off")) == 0)
                {
                    INTEGRATE = 0;
                    //putsUart0("\n\r TRUE");
                }
    }
    else
    {
        putsUart0("\n\r Invalid Command");
        putsUart0("\n\r");
    }

    //next command
}
//-----------------------------------------------------------------------------
// Main
//-----------------------------------------------------------------------------

int main(void)
{
    // Initialize hardware
    initHw();

    while (1)
    {
        led();
        putsUart0("\nEnter the string:\n\r");
        putsUart0("\n\r");
        getstring();
        putsUart0("\nEntered string is:\n\r");
        putsUart0(str);
        putsUart0("\n\r");
        //putsUart0("\nAfter parsing:\n\r ");
        parsestring();
        commands();
    }
}
